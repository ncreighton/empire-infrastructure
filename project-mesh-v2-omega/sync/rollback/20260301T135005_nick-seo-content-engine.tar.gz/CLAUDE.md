<!-- MESH:START -->

# -----------------------------------------------------------
# PROJECT MESH v2.0   AUTO-GENERATED CONTEXT
# Project: Nick SEO Content Engine
# Category: content-tools
# Priority: high
# Compiled: 2026-03-01 13:50
# -----------------------------------------------------------

# EMPIRE GLOBAL RULES
> These rules apply to EVERY project. No exceptions.

## Core Principles
1. **Never hardcode API keys, webhook URLs, or secrets** — Use environment variables
2. **Always use shared-core systems when available** — Check the registry first
3. **All API calls must use retry logic** — Use the api-retry shared system
4. **Images must be optimized before upload** — Use image-optimization system
5. **Content must pass SEO validation** — Use seo-toolkit system
6. **Never reference deprecated methods** — Check BLACKLIST.md below

## Technical Standards
- All WordPress sites use Blocksy or Astra themes on Hostinger
- All automation runs through n8n (ZimmWriter is DEPRECATED)
- All content generation uses Claude API (never GPT)
- All sites use LiteSpeed cache
- All affiliate links use affiliate-link-manager system

## Quality Standards
- Content demonstrates E-E-A-T signals
- Target featured snippets where applicable
- Proper schema markup on every page
- Images have alt text with target keywords
- Internal linking follows topical cluster strategy

## Brand Voice
- Each site has its own voice (see category context below)
- Never use generic AI-sounding language
- Never reference being AI-generated
- Content must feel human-written and authentic

## n8n Automation
- All content pipelines run through n8n workflows
- Use Steel.dev for browser automation with 10min keep-alive pings
- BrowserUse as fallback when Steel.dev fails
- All webhooks use environment variables, never hardcoded URLs

# DEPRECATED METHODS — NEVER USE THESE

> This file is auto-included in every project's CLAUDE.md.
> Updated: 2026-02-28

## Content Generation
### ❌ NEVER use ZimmWriter or ZimmWriter API
- **Replacement**: n8n content pipeline + Claude API
- **Reason**: Deprecated in favor of Claude-native workflows
- **Stage**: REMOVED

### ❌ NEVER use GPT/OpenAI for content generation
- **Replacement**: Claude API (Anthropic)
- **Reason**: All content uses Claude for consistency and quality

## API Patterns
### ❌ NEVER hardcode webhook URLs
- **Replacement**: Use environment variables or config.get('webhooks.name')
- **Reason**: Security risk and maintenance nightmare

### ❌ NEVER make API calls without retry logic
- **Replacement**: Use shared-core/api-retry system
- **Reason**: APIs fail. Always retry with exponential backoff.

### ❌ NEVER use fetch() directly for external APIs
- **Replacement**: Use the api-retry wrapper which handles retries, timeouts, and error logging
- **Reason**: Raw fetch has no retry, no timeout, no error handling

## WordPress
### ❌ NEVER use Yoast SEO plugin
- **Replacement**: RankMath
- **Reason**: Standardized across all sites on RankMath

### ❌ NEVER edit theme files directly
- **Replacement**: Use child theme or Blocksy customizer
- **Reason**: Updates will overwrite direct edits

## Substack
### ❌ NEVER use witchcraftforbeginners.substack.com
- **Replacement**: witchcraftb.substack.com
- **Reason**: Correct URL is witchcraftb.substack.com

## Browser Automation
### ❌ NEVER use Puppeteer directly
- **Replacement**: Steel.dev with BrowserUse fallback
- **Reason**: Standardized on Steel.dev for session management
- **Note**: Steel.dev sessions expire after 15min idle — implement keep-alive pings

## Content Vertical Context
- **Voice**: Scholarly wonder (mythology) / Creative organizer (journals)
- **Sites**: MythicalArchives, BulletJournals
- **Content pillars**: mythology deep dives, journaling techniques, templates, supplies


## Shared Systems (Current Versions)

| System | Version | Criticality | Usage |
|--------|---------|-------------|-------|
| api-retry | 1.0.0 [WARN] (latest: 1.1.0) | high | hourly |


## Relevant Knowledge Base Entries

- AI Vertical Context
- Content Guidelines Summary
- Content Vertical Context
- FORGE + AMPLIFY Intelligence System (INSTALLED)
- Family Vertical Context
- API Cost Optimization Rules
- AVOID: [X] NEVER use Yoast SEO plugin
- API Patterns

## Self-Check Before Starting Work
Before writing any code or content for Nick SEO Content Engine:
1. [OK] Am I using the latest shared systems? (Check version table above)
2. [OK] Am I avoiding ALL deprecated methods? (Check blacklist above)  
3. [OK] Am I using the correct brand voice for content-tools vertical?
4. [OK] Am I using api-retry for all external API calls?
5. [OK] Am I using environment variables for secrets/webhooks?

<!-- MESH:END -->

# CLAUDE.md - Nick's SEO Content Engine (NSCE)

## Project Overview
Building an enhanced SEOWriting.ai clone customized for Nick's 16-site WordPress publishing empire. This replaces ZimmWriter and external AI content tools with a superior, fully-integrated solution powered by Claude.

## Key Context
- **Owner**: Nick - operates 16 WordPress sites across witchcraft, tech, AI, family, mythology, and productivity niches
- **Current Stack**: n8n automation on Contabo VPS, WordPress sites with various themes
- **Primary Goal**: Eliminate dependency on ZimmWriter/SEOWriting.ai, build superior custom solution
- **Integration Points**: n8n workflows, WordPress REST API, Claude API

## The 16 Sites
1. WitchcraftForBeginners.com (flagship - witchcraft/spirituality)
2. SmartHomeWizards.com (smart home tech)
3. AIinActionHub.com (AI analysis)
4. AIDiscoveryDigest.com (AI curation)
5. WealthFromAI.com (AI monetization)
6. Family-Flourish.com (family wellness)
7. MythicalArchives.com (mythology)
8. BulletJournals.net (productivity)
9. Plus 8 additional sites in the network

## Voice Profiles (Critical)
Each site has a distinct voice that MUST be maintained:
- **Witchcraft sites**: Mystical warmth, wise mentor energy
- **Tech sites**: Authoritative, clear, practical
- **AI sites**: Forward analyst, data-driven
- **Family sites**: Nurturing, supportive
- **Mythology**: Scholarly wonder, storytelling

## Architecture Decisions
1. **Python backend** with FastAPI for API endpoints
2. **PostgreSQL** for structured data, content storage
3. **Redis** for caching and queue management
4. **Docker Compose** for containerization
5. **n8n integration** for workflow automation

## Core Modules to Build
1. **Article Generator** - Multi-stage content pipeline with quality gates
2. **SEO Optimizer** - SERP analysis, NLP keywords, content scoring
3. **Image Generator** - AI images contextual to content
4. **WordPress Publisher** - Multi-site publishing with scheduling
5. **Humanizer Engine** - AI detection bypass
6. **Internal Linker** - Smart linking across site content

## Code Style Guidelines
- Use type hints throughout Python code
- Document all public functions with docstrings
- Follow PEP 8 style guidelines
- Write async code where beneficial for I/O operations
- Keep functions focused and under 50 lines
- Use descriptive variable names

## File Organization
```
nick-seo-content-engine/
├── CLAUDE.md              # This file
├── SPECIFICATION.md       # Full feature specification
├── src/
│   ├── api/              # FastAPI routes
│   ├── core/             # Core business logic
│   │   ├── generator/    # Article generation
│   │   ├── seo/          # SEO optimization
│   │   ├── humanizer/    # AI detection bypass
│   │   └── publisher/    # WordPress publishing
│   ├── models/           # Pydantic models
│   ├── db/               # Database models & migrations
│   └── utils/            # Helper utilities
├── config/
│   ├── sites/            # Per-site configurations
│   └── templates/        # Content templates
├── tests/
├── docker/
└── docs/
```

## Environment Variables Required
```bash
# AI APIs
ANTHROPIC_API_KEY=
OPENAI_API_KEY=

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/nsce

# WordPress (per site)
WFB_WP_URL=https://witchcraftforbeginners.com/wp-json/wp/v2
WFB_WP_USER=
WFB_WP_PASSWORD=
# ... repeat for all 16 sites

# SEO APIs
SERP_API_KEY=
DATAFORSEO_KEY=

# Quality Checking
ORIGINALITY_AI_KEY=
```

## Key Commands
```bash
# Run development server
uvicorn src.api.main:app --reload

# Run tests
pytest tests/ -v

# Generate article (CLI)
python -m src.cli generate --site=witchcraftforbeginners --keyword="moon ritual"

# Bulk generate
python -m src.cli bulk-generate --site=smarthomewizards --csv=keywords.csv
```

## Important Notes
- Always maintain voice consistency per site
- Run AI detection check before publishing
- Use internal linking for all articles (3-5 links minimum)
- Generate meta title and description for every article
- Include FAQ schema where appropriate

## Current Priority
Phase 1: Core foundation with single article generation working end-to-end for one site (WitchcraftForBeginners as test site).
