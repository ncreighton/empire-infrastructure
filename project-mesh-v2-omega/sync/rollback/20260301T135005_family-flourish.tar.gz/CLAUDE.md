<!-- MESH:START -->

# -----------------------------------------------------------
# PROJECT MESH v2.0   AUTO-GENERATED CONTEXT
# Project: Family Flourish
# Category: family-sites
# Priority: high
# Compiled: 2026-03-01 13:49
# -----------------------------------------------------------

# EMPIRE GLOBAL RULES
> These rules apply to EVERY project. No exceptions.

## Core Principles
1. **Never hardcode API keys, webhook URLs, or secrets** — Use environment variables
2. **Always use shared-core systems when available** — Check the registry first
3. **All API calls must use retry logic** — Use the api-retry shared system
4. **Images must be optimized before upload** — Use image-optimization system
5. **Content must pass SEO validation** — Use seo-toolkit system
6. **Never reference deprecated methods** — Check BLACKLIST.md below

## Technical Standards
- All WordPress sites use Blocksy or Astra themes on Hostinger
- All automation runs through n8n (ZimmWriter is DEPRECATED)
- All content generation uses Claude API (never GPT)
- All sites use LiteSpeed cache
- All affiliate links use affiliate-link-manager system

## Quality Standards
- Content demonstrates E-E-A-T signals
- Target featured snippets where applicable
- Proper schema markup on every page
- Images have alt text with target keywords
- Internal linking follows topical cluster strategy

## Brand Voice
- Each site has its own voice (see category context below)
- Never use generic AI-sounding language
- Never reference being AI-generated
- Content must feel human-written and authentic

## n8n Automation
- All content pipelines run through n8n workflows
- Use Steel.dev for browser automation with 10min keep-alive pings
- BrowserUse as fallback when Steel.dev fails
- All webhooks use environment variables, never hardcoded URLs

# DEPRECATED METHODS — NEVER USE THESE

> This file is auto-included in every project's CLAUDE.md.
> Updated: 2026-02-28

## Content Generation
### ❌ NEVER use ZimmWriter or ZimmWriter API
- **Replacement**: n8n content pipeline + Claude API
- **Reason**: Deprecated in favor of Claude-native workflows
- **Stage**: REMOVED

### ❌ NEVER use GPT/OpenAI for content generation
- **Replacement**: Claude API (Anthropic)
- **Reason**: All content uses Claude for consistency and quality

## API Patterns
### ❌ NEVER hardcode webhook URLs
- **Replacement**: Use environment variables or config.get('webhooks.name')
- **Reason**: Security risk and maintenance nightmare

### ❌ NEVER make API calls without retry logic
- **Replacement**: Use shared-core/api-retry system
- **Reason**: APIs fail. Always retry with exponential backoff.

### ❌ NEVER use fetch() directly for external APIs
- **Replacement**: Use the api-retry wrapper which handles retries, timeouts, and error logging
- **Reason**: Raw fetch has no retry, no timeout, no error handling

## WordPress
### ❌ NEVER use Yoast SEO plugin
- **Replacement**: RankMath
- **Reason**: Standardized across all sites on RankMath

### ❌ NEVER edit theme files directly
- **Replacement**: Use child theme or Blocksy customizer
- **Reason**: Updates will overwrite direct edits

## Substack
### ❌ NEVER use witchcraftforbeginners.substack.com
- **Replacement**: witchcraftb.substack.com
- **Reason**: Correct URL is witchcraftb.substack.com

## Browser Automation
### ❌ NEVER use Puppeteer directly
- **Replacement**: Steel.dev with BrowserUse fallback
- **Reason**: Standardized on Steel.dev for session management
- **Note**: Steel.dev sessions expire after 15min idle — implement keep-alive pings

## Family Vertical Context
- **Voice**: Nurturing guide — warm, supportive, practical
- **Tone**: Experienced parent sharing what works
- **Sites**: Family-Flourish
- **Amazon tag**: familyflourish-20
- **Content pillars**: parenting, wellness, activities, product recommendations

## WordPress Standards
- Hostinger hosting with LiteSpeed cache enabled
- Blocksy or Astra theme
- RankMath for SEO (never Yoast)
- AI Engine plugin for Claude integration
- WP-CLI available for bulk operations
- Wordfence or Sucuri for security
- Regular backup schedule via Hostinger


## Shared Systems (Current Versions)

| System | Version | Criticality | Usage |
|--------|---------|-------------|-------|
| content-pipeline | 1.0.0 [OK] | critical | daily |
| image-optimization | 1.0.0 [OK] | high | daily |
| seo-toolkit | 1.0.0 [OK] | critical | daily |
| api-retry | 1.0.0 [OK] | high | hourly |
| wordpress-automation | 1.0.0 [OK] | high | daily |
| affiliate-link-manager | 1.0.0 [OK] | high | weekly |


## Relevant Knowledge Base Entries

- API Endpoints
- AVOID: [X] NEVER use GPT/OpenAI for content generation
- AVOID: [X] NEVER use Puppeteer directly
- AVOID: [X] NEVER use ZimmWriter or ZimmWriter API
- Browser Automation
- AI Vertical Context
- API Cost Optimization Rules
- AVOID: [X] NEVER use Yoast SEO plugin
- API Patterns

## Self-Check Before Starting Work
Before writing any code or content for Family Flourish:
1. [OK] Am I using the latest shared systems? (Check version table above)
2. [OK] Am I avoiding ALL deprecated methods? (Check blacklist above)  
3. [OK] Am I using the correct brand voice for family-sites vertical?
4. [OK] Am I using api-retry for all external API calls?
5. [OK] Am I using environment variables for secrets/webhooks?

<!-- MESH:END -->

# Family-Flourish - MEGA Claude Context v3.0
# Domain: family-flourish.com
# Generated: 2025-12-15
# Priority: MEDIUM | Site 16 of 16

## ============================================================
## SITE IDENTITY & BRAND
## ============================================================

### Core Identity
- **Site Name**: Family-Flourish
- **Domain**: family-flourish.com
- **Niche**: Family Wellness
- **Priority**: MEDIUM
- **Owner**: Nick Creighton
- **Project Folder**: family-flourish

### Brand Voice Profile
```yaml
tone: "nurturing guide"
style: "Warm, supportive, evidence-based"
avoid: "Judgment, one-size-fits-all, mom-shaming"
personality_traits:
  - Authentic and knowledgeable
  - Helpful without being preachy
  - Conversational yet professional
  - Actionable and practical
```

### Target Audience
Parents, caregivers, families

### Content Pillars
- Parenting strategies
- Family activities
- Child development
- Work-life balance

### Primary Keywords
- family activities
- parenting tips
- work life balance parents

## ============================================================
## WORDPRESS CONFIGURATION
## ============================================================

### Admin Access
```yaml
url: https://family-flourish.com/wp-admin/
username: FamilyGrowthGuide
app_password: l3GZ cIWV B07D 30Y3 1FR2 PRWG
amazon_tag: familyflourish-20
```

### REST API Endpoints
```
Base: https://family-flourish.com/wp-json/wp/v2/
Posts: /posts
Pages: /pages
Media: /media
Categories: /categories
Tags: /tags
Custom: /ai-engine/v1/ (if AI Engine installed)
```

### Required WordPress Plugins
- AI Engine (MCP integration) - CRITICAL
- Rank Math SEO
- LiteSpeed Cache
- Elementor or Gutenberg
- Advanced Custom Fields (optional)

### Theme Configuration
- Recommended: Blocksy, Flavor, or Flavor
- Child theme: Required for customizations
- Custom CSS: Appearance > Customize > Additional CSS

## ============================================================
## AI ENGINE MCP INTEGRATION
## ============================================================

### MCP Configuration (for .mcp/claude_desktop_config.json)
```json
{
  "mcpServers": {
    "ai-engine-family-flourish": {
      "command": "npx",
      "args": ["-y", "@anthropic/mcp-server-fetch"],
      "env": {
        "AI_ENGINE_URL": "https://family-flourish.com/wp-json/ai-engine-mcp/v1",
        "AI_ENGINE_TOKEN": "CONFIGURE_YOUR_TOKEN_HERE"
      }
    }
  }
}
```

### AI Engine No-Auth URL Pattern
```
https://family-flourish.com/wp-json/mcp/v1/sse?token=YOUR_TOKEN_HERE
```
**Note**: Token is IN the URL path - no separate auth header needed.

### Available MCP Tools (when connected)
- `create_post` - Create WordPress posts
- `update_post` - Update existing posts
- `get_posts` - Retrieve posts with filters
- `upload_media` - Upload images/files
- `get_categories` - List categories
- `get_tags` - List tags
- `create_page` - Create pages
- `get_site_info` - Site metadata

## ============================================================
## SYSTEME.IO INTEGRATION
## ============================================================

### Integration Status for Family-Flourish
```yaml
blog_sync: true
email_sequences: true
funnels: ['family-planner']
automations: ['weekly-activity-ideas']
```

### Systeme.io Global Credentials
```yaml
email: aiautomationblueprint@gmail.com
password: Ashlynn.09
api_key: 82tyjz6r3hzl5kq6qyl9ix9rusrkh3j7c8abj0fxaotfu4ruqftksnvuwxujhloc
```

### Browser Automation Required For
- Blog post creation (API doesn't support)
- Funnel page editing
- Email campaign creation
- Automation rule setup
- Media uploads

**See**: `C:\Claude Code Projects\skills\systeme-io-browser-automation\SKILL.md`

### Fallback Chain
1. Browserbase MCP + Stagehand (primary)
2. Steel.dev API (first fallback)
3. BrowserUse API (second fallback)

## ============================================================
## CONTENT STRATEGY
## ============================================================

### Content Types
| Type | Word Count | Purpose |
|------|------------|---------|
| Pillar | 3,000-5,000 | Comprehensive guides, topical authority |
| Cluster | 1,500-2,500 | Supporting articles, internal links |
| Quick | 500-1,000 | News, tips, product spotlights |

### SEO Strategy
```yaml
focus: Topical authority building
approach: Hub and spoke content clusters
e_e_a_t_signals:
  - Author bios with credentials
  - External expert citations
  - First-hand experience mentions
  - Updated dates on all content
  
schema_types:
  - Article
  - HowTo
  - FAQPage
  - Product (for reviews)
  - Review
  
internal_linking:
  - Minimum 3 internal links per post
  - Link to pillar content from clusters
  - Use descriptive anchor text
```

### Publishing Schedule
```yaml
frequency: 3-5 posts per week (automated)
best_days: Tuesday, Wednesday, Thursday
best_times: 9am, 12pm, 3pm EST
evergreen_ratio: 80% evergreen, 20% timely
```

## ============================================================
## AUTOMATION WORKFLOWS
## ============================================================

### n8n Content Pipeline
```yaml
trigger: Schedule (daily) or Webhook
steps:
  1. Fetch trending topics (Exa/web search)
  2. Generate content outline (Claude)
  3. Write full article (Claude)
  4. Generate featured image (DALL-E/Ideogram)
  5. Optimize for SEO (Rank Math integration)
  6. Publish to WordPress (REST API)
  7. Syndicate to Systeme.io (browser automation)
  8. Post to social (Buffer/native APIs)
  9. Log to monitoring sheet
```

### Available Automation Tools
- **n8n**: Primary automation platform (not Make.com)
- **Claude API**: Content generation
- **WordPress REST API**: Publishing
- **Systeme.io Browser Automation**: Email/funnel sync
- **Steel.dev/BrowserUse**: Fallback browser control

## ============================================================
## API CREDENTIALS
## ============================================================

### Site-Specific WordPress
```yaml
site_url: https://family-flourish.com
rest_api: https://family-flourish.com/wp-json/wp/v2/
username: FamilyGrowthGuide
app_password: l3GZ cIWV B07D 30Y3 1FR2 PRWG
amazon_tag: familyflourish-20
```

### Global Browser Automation
```yaml
steel_dev: ste-A43JGQkLsnI609gNUXatQ83QB88Aj2JHOyrhvdaax8AxCWwSI0sn3VD01ToP4RjxM5POgbxoDhaEcwmsxshm6BFtKYS8J2ErKFy
browseruse: bu_YUQ0ZqtuWge86lOZUaWiZtK_rG6PkCNElONERb9Jzgs
```

### Global Image APIs
```yaml
pexels: 1hzvRtRuqZi6qLk5XF5pnT6onl50kTMK5nkGnNhkgNEkJGb9TQWKxtmZ
unsplash_access: xP0BIeSFhQj0Px3NPQyxRZzIrEUfVM_DyQHtG_WidEU
unsplash_secret: c-tsP1K-o01-N8njud704gYT9kGgHJd07zbilb0i63U
```

### Global Other APIs
```yaml
github_pat: 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
v0_api: v1:Gc9e6pCtq5X2AkIkYhEEBzDL:cEDxU9gxvibKpVjdqkkbEZN4
composio: ak_SLr_ZlO7QJr63Y7Z6f6p
systeme_api: 82tyjz6r3hzl5kq6qyl9ix9rusrkh3j7c8abj0fxaotfu4ruqftksnvuwxujhloc
```

## ============================================================
## DESIGN SYSTEM
## ============================================================

### Design Philosophy
**"Modern Tech Picasso"** - Unexpected, striking, memorable designs that never look AI-generated.

### v0.dev Component Generation
```yaml
api_key: v1:Gc9e6pCtq5X2AkIkYhEEBzDL:cEDxU9gxvibKpVjdqkkbEZN4
endpoint: https://api.v0.dev/v1/generate
use_for:
  - Hero sections
  - Feature cards
  - Pricing tables
  - Navigation components
  - Call-to-action blocks
```

## ============================================================
## ACTIVE SKILLS
## ============================================================

### Global Skills (in /mnt/skills/)
```
/mnt/skills/public/docx/SKILL.md       - Document creation
/mnt/skills/public/pdf/SKILL.md        - PDF handling
/mnt/skills/public/pptx/SKILL.md       - Presentations
/mnt/skills/public/xlsx/SKILL.md       - Spreadsheets
/mnt/skills/public/frontend-design/SKILL.md - UI design

/mnt/skills/user/wordpress-empire-system/SKILL.md
/mnt/skills/user/n8n-master-architect/SKILL.md
/mnt/skills/user/browser-automation-superagent/SKILL.md
/mnt/skills/user/witchcraft-substack-voice/SKILL.md (for WitchcraftForBeginners)
```

### Local Skills (in C:\Claude Code Projects\skills\)
```
systeme-io-browser-automation/SKILL.md
systeme-io-browser-automation/STAGEHAND-IMPLEMENTATION.md
systeme-io-browser-automation/QUICK-REFERENCE.md
```

## ============================================================
## CURRENT TASKS & PRIORITIES
## ============================================================

### Active Tasks for Family-Flourish
- [ ] Holiday family activities
- [ ] 2025 family calendar printable

### Known Issues
- ✅ No known issues

### Priority Order
1. Fix any critical issues first
2. Complete automation setup
3. Generate initial content batch
4. Set up Systeme.io integration (if enabled)
5. Configure monitoring

## ============================================================
## QUICK COMMANDS
## ============================================================

### Content Generation
```
"Generate a pillar article about [TOPIC] for family-flourish.com"
"Create 5 cluster articles supporting [PILLAR]"
"Write a product review for [PRODUCT] with affiliate links using familyflourish-20"
```

### WordPress Operations
```
"Create a new post titled [TITLE] with category [CAT]"
"Update the homepage hero section"
"Add schema markup to existing posts"
```

### Automation
```
"Set up n8n workflow for daily content publishing"
"Configure Systeme.io blog sync"
"Create email welcome sequence"
```

### SEO
```
"Audit SEO for last 10 posts"
"Generate internal linking suggestions"
"Create FAQ schema for [POST]"
```

## ============================================================
## SITE-SPECIFIC RULES
## ============================================================

### DO ✓
- Maintain "nurturing guide" voice consistently
- Include relevant affiliate links (familyflourish-20)
- Optimize all images before upload
- Use proper heading hierarchy (H1 > H2 > H3)
- Include at least one CTA per post
- Add alt text to all images
- Follow E-E-A-T guidelines

### DON'T ✗
- Judgment, one-size-fits-all, mom-shaming
- Use generic AI-sounding phrases
- Publish without SEO optimization
- Forget internal links (minimum 3 per post)
- Skip featured images
- Ignore mobile responsiveness

## ============================================================
## MEMORY CONTEXT
## ============================================================

### Mem0 Integration
```yaml
user_id: nick-creighton
auto_store: true
search_first: true
```

### Key Facts
- This is site 16 of 16 in Nick's publishing empire
- Flagship site is WitchcraftForBeginners
- Primary automation platform is n8n (not Make.com)
- ZimmWriter is deprecated - use Claude/n8n only
- Design philosophy: "Modern Tech Picasso"
- All 16 sites have MEGA v3.0 enhancement

## ============================================================
## ERROR HANDLING & FALLBACKS
## ============================================================

### If MCP Connection Fails
1. Check AI Engine token in .env
2. Verify WordPress site is accessible
3. Try Steel.dev browser automation as fallback
4. Use BrowserUse if Steel.dev fails
5. Log error for debugging

### Browser Automation Fallback Chain
```
1. Browserbase MCP + Stagehand (primary)
2. Steel.dev API (first fallback)  
3. BrowserUse API (second fallback)
4. Manual intervention (last resort)
```

## ============================================================
## FILE STRUCTURE
## ============================================================

### This Project Folder
```
family-flourish/
├── CLAUDE.md              (this file - MEGA v3.0)
├── auto-start-claude.bat  (Windows launcher)
├── .env                   (local environment vars)
├── .env.template          (template for .env)
├── .mcp/
│   └── claude_desktop_config.json
├── content/               (generated content)
├── assets/                (images, media)
└── logs/                  (automation logs)
```

### Global Resources
```
C:\Claude Code Projects\
├── _MASTER-EMPIRE/        (master configs)
├── skills/                (shared skills)
├── automation/            (shared workflows)
├── schemas/               (API schemas)
├── templates/             (shared templates)
└── [16 site folders]/     (individual sites)
```

## ============================================================
## VERSION HISTORY
## ============================================================

| Version | Date | Changes |
|---------|------|---------|
| v3.0 | 2025-12-15 | MEGA enhancement - comprehensive context |
| v2.0 | 2025-12 | Added Systeme.io browser automation |
| v1.0 | 2025-11 | Initial Claude Code setup |

---

# END OF MEGA CONTEXT v3.0
# Site: Family-Flourish | Domain: family-flourish.com | Priority: MEDIUM
# Total: ~500 lines of comprehensive context for optimal Claude Code performance

---

## API Cost Optimization Rules

### Model Selection (MANDATORY)
When generating code that calls Anthropic's API:

1. **Default to Sonnet** (`claude-sonnet-4-20250514`) for most tasks
2. **Use Haiku** (`claude-haiku-4-5-20251001`) for:
   - Classification tasks
   - Intent detection
   - Simple data extraction
   - Yes/no decisions
   - Formatting/conversion
   - Tag generation
3. **Reserve Opus** (`claude-opus-4-20250514`) ONLY for:
   - Complex multi-step reasoning
   - Critical business decisions
   - Nuanced editorial judgment

### Prompt Caching (ALWAYS ENABLE)
When system prompts exceed 2,048 tokens, ALWAYS use cache_control:

```python
message = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=2048,
    system=[
        {
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[{"role": "user", "content": user_input}]
)
```

### Token Limits
| Output Type | max_tokens |
|-------------|------------|
| Yes/no, classification | 50-100 |
| Short response | 200-500 |
| Article section | 1000-2000 |
| Full article | 3000-4096 |

### Quick Reference
```
Model Strings (Dec 2025):
- claude-haiku-4-5-20251001    → Simple tasks
- claude-sonnet-4-20250514     → Default
- claude-opus-4-20250514       → Complex only

Pricing per 1M tokens:
- Haiku:  $0.80 in / $4.00 out
- Sonnet: $3.00 in / $15.00 out
- Opus:   $15.00 in / $75.00 out
- Cache reads: 90% discount
- Batch API: 50% discount
```
