<!-- MESH:START -->

# -----------------------------------------------------------
# PROJECT MESH v2.0   AUTO-GENERATED CONTEXT
# Project: PinFlux Engine
# Category: ecommerce
# Priority: normal
# Compiled: 2026-03-01 13:50
# -----------------------------------------------------------

# EMPIRE GLOBAL RULES
> These rules apply to EVERY project. No exceptions.

## Core Principles
1. **Never hardcode API keys, webhook URLs, or secrets** — Use environment variables
2. **Always use shared-core systems when available** — Check the registry first
3. **All API calls must use retry logic** — Use the api-retry shared system
4. **Images must be optimized before upload** — Use image-optimization system
5. **Content must pass SEO validation** — Use seo-toolkit system
6. **Never reference deprecated methods** — Check BLACKLIST.md below

## Technical Standards
- All WordPress sites use Blocksy or Astra themes on Hostinger
- All automation runs through n8n (ZimmWriter is DEPRECATED)
- All content generation uses Claude API (never GPT)
- All sites use LiteSpeed cache
- All affiliate links use affiliate-link-manager system

## Quality Standards
- Content demonstrates E-E-A-T signals
- Target featured snippets where applicable
- Proper schema markup on every page
- Images have alt text with target keywords
- Internal linking follows topical cluster strategy

## Brand Voice
- Each site has its own voice (see category context below)
- Never use generic AI-sounding language
- Never reference being AI-generated
- Content must feel human-written and authentic

## n8n Automation
- All content pipelines run through n8n workflows
- Use Steel.dev for browser automation with 10min keep-alive pings
- BrowserUse as fallback when Steel.dev fails
- All webhooks use environment variables, never hardcoded URLs

# DEPRECATED METHODS — NEVER USE THESE

> This file is auto-included in every project's CLAUDE.md.
> Updated: 2026-02-28

## Content Generation
### ❌ NEVER use ZimmWriter or ZimmWriter API
- **Replacement**: n8n content pipeline + Claude API
- **Reason**: Deprecated in favor of Claude-native workflows
- **Stage**: REMOVED

### ❌ NEVER use GPT/OpenAI for content generation
- **Replacement**: Claude API (Anthropic)
- **Reason**: All content uses Claude for consistency and quality

## API Patterns
### ❌ NEVER hardcode webhook URLs
- **Replacement**: Use environment variables or config.get('webhooks.name')
- **Reason**: Security risk and maintenance nightmare

### ❌ NEVER make API calls without retry logic
- **Replacement**: Use shared-core/api-retry system
- **Reason**: APIs fail. Always retry with exponential backoff.

### ❌ NEVER use fetch() directly for external APIs
- **Replacement**: Use the api-retry wrapper which handles retries, timeouts, and error logging
- **Reason**: Raw fetch has no retry, no timeout, no error handling

## WordPress
### ❌ NEVER use Yoast SEO plugin
- **Replacement**: RankMath
- **Reason**: Standardized across all sites on RankMath

### ❌ NEVER edit theme files directly
- **Replacement**: Use child theme or Blocksy customizer
- **Reason**: Updates will overwrite direct edits

## Substack
### ❌ NEVER use witchcraftforbeginners.substack.com
- **Replacement**: witchcraftb.substack.com
- **Reason**: Correct URL is witchcraftb.substack.com

## Browser Automation
### ❌ NEVER use Puppeteer directly
- **Replacement**: Steel.dev with BrowserUse fallback
- **Reason**: Standardized on Steel.dev for session management
- **Note**: Steel.dev sessions expire after 15min idle — implement keep-alive pings


## Shared Systems (Current Versions)

| System | Version | Criticality | Usage |
|--------|---------|-------------|-------|
| api-retry | 1.0.0 [WARN] (latest: 1.1.0) | high | hourly |


## Relevant Knowledge Base Entries

- API Endpoints
- AVOID: [X] NEVER use GPT/OpenAI for content generation
- AVOID: [X] NEVER use Puppeteer directly
- AVOID: [X] NEVER use ZimmWriter or ZimmWriter API
- Browser Automation
- AVOID: [X] NEVER use Yoast SEO plugin
- API Patterns

## Self-Check Before Starting Work
Before writing any code or content for PinFlux Engine:
1. [OK] Am I using the latest shared systems? (Check version table above)
2. [OK] Am I avoiding ALL deprecated methods? (Check blacklist above)  
3. [OK] Am I using the correct brand voice for ecommerce vertical?
4. [OK] Am I using api-retry for all external API calls?
5. [OK] Am I using environment variables for secrets/webhooks?

<!-- MESH:END -->

# PinFlux Engine v2.0 - Enhanced Claude Code Project

## 🎯 Project Vision

**The Ultimate Pinterest Automation System** - A BlogToPin clone that leverages your entire tech stack for maximum efficiency and pin quality.

---

## ⚡ QUICK START FOR CLAUDE CODE

```bash
# 1. Read the skill first
cat skills/pinflux-core/SKILL.md

# 2. Tell Claude Code:
"I'm building PinFlux Engine. Read the pinflux-core skill and CLAUDE.md, then help me with Phase 2"
```

---

## 🔌 Integrated Services & APIs

### Core Infrastructure
| Service | Purpose | Status |
|---------|---------|--------|
| **n8n** (Contabo) | Workflow orchestration | ✅ Ready |
| **PostgreSQL** | Data storage | 🔨 Configure |
| **Redis** | Caching & queues | 🔨 Configure |

### Template & Image Generation
| Service | Purpose | Priority |
|---------|---------|----------|
| **Canva MCP** | Professional templates, drag-drop editing | PRIMARY |
| **Puppeteer** | Self-hosted HTML/CSS rendering | FALLBACK |
| **Ideogram API** | AI background generation | ENHANCEMENT |
| **Freepik API** | Stock images & vectors | ENHANCEMENT |
| **Runware** | Fast AI image generation | ENHANCEMENT |
| **Replicate** | Model variety (SDXL, etc.) | ENHANCEMENT |

### Content & Research
| Service | Purpose |
|---------|---------|
| **Exa** | Semantic search for trending topics |
| **Context7** | Documentation & API reference lookup |
| **WordPress REST** | Content ingestion from your 16 sites |

### Optimization & Delivery
| Service | Purpose |
|---------|---------|
| **Cloudinary** | Image optimization, CDN, transformations |
| **v0 API** | UI component generation for admin dashboard |

### Management & Tracking
| Service | Purpose |
|---------|---------|
| **Notion** | Campaign management, content calendar |
| **Google Sheets** | Analytics tracking, performance reports |

### AI & Copy
| Service | Purpose |
|---------|---------|
| **Claude API** | Pin copy generation with brand personas |
| **OpenAI** | Fallback for copy generation |

---

## 📁 Project Structure

```
pinflux-engine/
├── CLAUDE.md                    ← You are here
├── START_PROJECT.bat            ← Windows launcher
│
├── skills/                      ← CUSTOM SKILLS FOR THIS PROJECT
│   ├── pinflux-core/SKILL.md
│   ├── pinflux-templates/SKILL.md
│   ├── pinflux-pinterest/SKILL.md
│   └── pinflux-images/SKILL.md
│
├── docs/
│   ├── 00-integrations.md       ← API setup guide
│   ├── 01-architecture.md       ← System design
│   ├── 02-pinterest-api.md      ← Pinterest reference
│   ├── 03-templates-rendering.md
│   ├── 04-build-phases.md       ← Step-by-step guide
│   ├── 05-image-generation.md   ← AI image APIs
│   └── 06-canva-integration.md  ← Canva MCP usage
│
├── backend/src/
│   ├── services/
│   │   ├── pinterest/           ← Pinterest API
│   │   ├── canva/               ← Canva MCP
│   │   ├── images/              ← Image generation
│   │   ├── cloudinary/          ← CDN
│   │   ├── content/             ← WordPress ingestion
│   │   ├── copy/                ← AI copy
│   │   └── scheduler/           ← Smart scheduling
│   └── integrations/
│       ├── exa.ts               ← Trending research
│       ├── notion.ts            ← Campaigns
│       └── sheets.ts            ← Reports
│
├── n8n-workflows/               ← Pre-built workflows
├── config/brand-packs/          ← Per-site brands
├── database/migrations/
└── .env.example
```

---

## 🏗️ Architecture

```
CONTENT SOURCES                    IMAGE GENERATION              TEMPLATE ENGINE
┌─────────────┐                   ┌─────────────┐              ┌─────────────┐
│ WordPress   │                   │ Ideogram    │              │ Canva MCP   │
│ (16 sites)  │                   │ Freepik     │              │ (Primary)   │
│ Exa Research│                   │ Runware     │              │ Puppeteer   │
└──────┬──────┘                   │ Replicate   │              │ (Fallback)  │
       │                          └──────┬──────┘              └──────┬──────┘
       │                                 │                            │
       ▼                                 ▼                            ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                        n8n ORCHESTRATION (Contabo)                          │
│                                                                             │
│   Ingest → Generate Images → Create Copy → Render Template → Schedule      │
└────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                          ┌─────────────────┐
                          │  CLOUDINARY CDN │
                          │  (Optimization) │
                          └────────┬────────┘
                                   │
                                   ▼
                          ┌─────────────────┐
                          │ PINTEREST API   │
                          │ (Multi-Account) │
                          └────────┬────────┘
                                   │
       ┌───────────────────────────┼───────────────────────────┐
       ▼                           ▼                           ▼
┌─────────────┐            ┌─────────────┐            ┌─────────────┐
│  PostgreSQL │            │   Notion    │            │   Sheets    │
│  (Data)     │            │ (Campaigns) │            │ (Reports)   │
└─────────────┘            └─────────────┘            └─────────────┘
```

---

## 🔧 Build Phases

| Phase | Description | Key Integrations |
|-------|-------------|------------------|
| 1 | Infrastructure | Docker, Postgres, Redis, n8n |
| 2 | Pinterest Core | OAuth, Multi-account, Boards |
| 3 | Content Pipeline | WordPress, Exa research |
| 4 | Image Stack | Cloudinary, Ideogram, Freepik, Runware |
| 5 | Templates | Canva MCP, Puppeteer fallback |
| 6 | AI Copy | Claude personas, brand voices |
| 7 | Scheduler | Smart timing, daily limits |
| 8 | Analytics | Notion, Sheets, optimization |
| 9 | Dashboard | v0 UI components |

**See `docs/04-build-phases.md` for detailed instructions.**

---

## 💰 Services to Set Up

### Free / Already Have
- ✅ n8n (Contabo)
- ✅ Claude API
- ✅ Canva MCP
- ✅ Notion (free tier)
- ✅ Google Sheets
- ✅ Cloudinary (free tier: 25GB)

### Need API Keys
- Ideogram API
- Freepik API
- Runware API
- Replicate API
- Exa API

---

## 🎨 Unique Pin Generation Strategy

```
For each piece of content, we can generate:

1. TEMPLATE VARIANTS
   - Canva template A (e.g., bold headline)
   - Canva template B (e.g., minimal)
   - Puppeteer template C (e.g., quote style)

2. IMAGE VARIANTS
   - Original featured image (from WordPress)
   - AI-generated background (Ideogram)
   - Stock image match (Freepik)

3. COPY VARIANTS
   - Hook style A (curiosity)
   - Hook style B (benefit)
   - Hook style C (urgency)

Result: 3 × 3 × 3 = 27 unique pin possibilities per post!
```

---

## 🔐 Pinterest Safety Built-In

- Daily limits per account (configurable, default 40)
- Minimum spacing (15+ minutes)
- Posting hours (8 AM - 11 PM)
- Human-like randomization (±2 min jitter)
- Automatic cooldown on rate limits
- Board rotation

---

## 📋 Required Environment Variables

```bash
# Core
POSTGRES_PASSWORD=
REDIS_URL=
N8N_HOST=your-contabo-n8n.com

# Pinterest
PINTEREST_APP_ID=
PINTEREST_APP_SECRET=

# Image Generation
IDEOGRAM_API_KEY=
FREEPIK_API_KEY=
RUNWARE_API_KEY=
REPLICATE_API_TOKEN=

# CDN
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=

# AI
ANTHROPIC_API_KEY=

# Research
EXA_API_KEY=

# Tracking
NOTION_API_KEY=
NOTION_DATABASE_ID=
```

---

## ⏭️ Next Steps

1. **Download this project**
2. **Copy to your projects folder**
3. **Open in Claude Code**
4. **Say:** "Read skills/pinflux-core/SKILL.md and help me configure infrastructure"

---

*PinFlux Engine v2.0*
*Built for Nick's 16-site publishing empire*

---

## Image Hosting Rules (CRITICAL)

**For any images displayed on WordPress sites:**

1. **NEVER use ngrok URLs** - they are temporary and will break
2. **ALWAYS upload to WordPress** media library for content images
3. **SEO-optimized filenames required:**
   - Format: `{keyword}-{descriptor}-{site}.png`
   - Example: `smart-home-guide-featured-smarthomewizards.png`
4. **ALWAYS set alt text** with target keyword
5. **ALWAYS set title attribute** for accessibility

**For Pinterest pins (exception):**
- Cloudinary CDN is acceptable for pin images since Pinterest hosts the final image
- However, if the pin image is also used as featured image on WordPress, upload to WordPress first

```python
# For content/featured images - ALWAYS WordPress
wp_url = upload_to_wordpress(site_id, image_path, seo_filename)

# WRONG - Never for WordPress content
image_url = "https://something.ngrok.dev/image.png"  # NEVER
```

---

## API Cost Optimization Rules

### Model Selection (MANDATORY)
When generating code that calls Anthropic's API:

1. **Default to Sonnet** (`claude-sonnet-4-20250514`) for most tasks
2. **Use Haiku** (`claude-haiku-4-5-20251001`) for:
   - Classification tasks
   - Intent detection
   - Simple data extraction
   - Yes/no decisions
   - Formatting/conversion
   - Tag generation
3. **Reserve Opus** (`claude-opus-4-20250514`) ONLY for:
   - Complex multi-step reasoning
   - Critical business decisions
   - Nuanced editorial judgment

### Prompt Caching (ALWAYS ENABLE)
When system prompts exceed 2,048 tokens, ALWAYS use cache_control:

```python
message = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=2048,
    system=[
        {
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[{"role": "user", "content": user_input}]
)
```

### Token Limits
| Output Type | max_tokens |
|-------------|------------|
| Yes/no, classification | 50-100 |
| Short response | 200-500 |
| Article section | 1000-2000 |
| Full article | 3000-4096 |

### Quick Reference
```
Model Strings (Dec 2025):
- claude-haiku-4-5-20251001    → Simple tasks
- claude-sonnet-4-20250514     → Default
- claude-opus-4-20250514       → Complex only

Pricing per 1M tokens:
- Haiku:  $0.80 in / $4.00 out
- Sonnet: $3.00 in / $15.00 out
- Opus:   $15.00 in / $75.00 out
- Cache reads: 90% discount
- Batch API: 50% discount
```
