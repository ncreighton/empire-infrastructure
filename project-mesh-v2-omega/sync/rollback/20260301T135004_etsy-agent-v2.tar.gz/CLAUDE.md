<!-- MESH:START -->

# -----------------------------------------------------------
# PROJECT MESH v2.0   AUTO-GENERATED CONTEXT
# Project: Etsy Agent v2
# Category: ecommerce
# Priority: high
# Compiled: 2026-03-01 13:49
# -----------------------------------------------------------

# EMPIRE GLOBAL RULES
> These rules apply to EVERY project. No exceptions.

## Core Principles
1. **Never hardcode API keys, webhook URLs, or secrets** — Use environment variables
2. **Always use shared-core systems when available** — Check the registry first
3. **All API calls must use retry logic** — Use the api-retry shared system
4. **Images must be optimized before upload** — Use image-optimization system
5. **Content must pass SEO validation** — Use seo-toolkit system
6. **Never reference deprecated methods** — Check BLACKLIST.md below

## Technical Standards
- All WordPress sites use Blocksy or Astra themes on Hostinger
- All automation runs through n8n (ZimmWriter is DEPRECATED)
- All content generation uses Claude API (never GPT)
- All sites use LiteSpeed cache
- All affiliate links use affiliate-link-manager system

## Quality Standards
- Content demonstrates E-E-A-T signals
- Target featured snippets where applicable
- Proper schema markup on every page
- Images have alt text with target keywords
- Internal linking follows topical cluster strategy

## Brand Voice
- Each site has its own voice (see category context below)
- Never use generic AI-sounding language
- Never reference being AI-generated
- Content must feel human-written and authentic

## n8n Automation
- All content pipelines run through n8n workflows
- Use Steel.dev for browser automation with 10min keep-alive pings
- BrowserUse as fallback when Steel.dev fails
- All webhooks use environment variables, never hardcoded URLs

# DEPRECATED METHODS — NEVER USE THESE

> This file is auto-included in every project's CLAUDE.md.
> Updated: 2026-02-28

## Content Generation
### ❌ NEVER use ZimmWriter or ZimmWriter API
- **Replacement**: n8n content pipeline + Claude API
- **Reason**: Deprecated in favor of Claude-native workflows
- **Stage**: REMOVED

### ❌ NEVER use GPT/OpenAI for content generation
- **Replacement**: Claude API (Anthropic)
- **Reason**: All content uses Claude for consistency and quality

## API Patterns
### ❌ NEVER hardcode webhook URLs
- **Replacement**: Use environment variables or config.get('webhooks.name')
- **Reason**: Security risk and maintenance nightmare

### ❌ NEVER make API calls without retry logic
- **Replacement**: Use shared-core/api-retry system
- **Reason**: APIs fail. Always retry with exponential backoff.

### ❌ NEVER use fetch() directly for external APIs
- **Replacement**: Use the api-retry wrapper which handles retries, timeouts, and error logging
- **Reason**: Raw fetch has no retry, no timeout, no error handling

## WordPress
### ❌ NEVER use Yoast SEO plugin
- **Replacement**: RankMath
- **Reason**: Standardized across all sites on RankMath

### ❌ NEVER edit theme files directly
- **Replacement**: Use child theme or Blocksy customizer
- **Reason**: Updates will overwrite direct edits

## Substack
### ❌ NEVER use witchcraftforbeginners.substack.com
- **Replacement**: witchcraftb.substack.com
- **Reason**: Correct URL is witchcraftb.substack.com

## Browser Automation
### ❌ NEVER use Puppeteer directly
- **Replacement**: Steel.dev with BrowserUse fallback
- **Reason**: Standardized on Steel.dev for session management
- **Note**: Steel.dev sessions expire after 15min idle — implement keep-alive pings


## Shared Systems (Current Versions)

| System | Version | Criticality | Usage |
|--------|---------|-------------|-------|
| api-retry | 1.0.0 [OK] | high | hourly |


## Relevant Knowledge Base Entries

- API Endpoints
- AVOID: [X] NEVER use GPT/OpenAI for content generation
- AVOID: [X] NEVER use Puppeteer directly
- AVOID: [X] NEVER use ZimmWriter or ZimmWriter API
- Browser Automation
- Important Notes
- COMMANDS
- API Patterns

## Self-Check Before Starting Work
Before writing any code or content for Etsy Agent v2:
1. [OK] Am I using the latest shared systems? (Check version table above)
2. [OK] Am I avoiding ALL deprecated methods? (Check blacklist above)  
3. [OK] Am I using the correct brand voice for ecommerce vertical?
4. [OK] Am I using api-retry for all external API calls?
5. [OK] Am I using environment variables for secrets/webhooks?

<!-- MESH:END -->

# ETSY INTELLIGENCE AGENT
## CLAUDE.md - Data Collection & Pattern Detection System

---

## WHAT THIS DOES

**One job:** Find what's selling on Etsy and why. Collect data. Find patterns. Surface opportunities.

This agent:
- Searches Etsy systematically across 2000+ keyword combinations
- Scrapes listings, shops, reviews, and search results
- Stores everything in a database that compounds over time
- Detects patterns in titles, tags, prices, and photos
- Identifies gaps and opportunities
- Tells you exactly what to make next

---

## SKILLS TO READ

```
C:\Claude Code Projects\etsy-agent-v2\skills\browser-automation.md
C:\Claude Code Projects\etsy-agent-v2\skills\n8n-automation.md
C:\Claude Code Projects\etsy-agent-v2\ETSY-SCRAPER-AGENT-SKILL.md
```

---

## TOOLS & CREDENTIALS

```yaml
# Browser Automation
Playwright: Local browser automation (no API key needed)
  pip install playwright
  playwright install chromium

# Database (Supabase)
Supabase URL: https://pkiwwdrzsbfqhbmnmfnl.supabase.co
Supabase Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBraXd3ZHJ6c2JmcWhibW5tZm5sIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NjA4NDQ3NiwiZXhwIjoyMDgxNjYwNDc2fQ.MFdyX2mDK9YLesQJY4vWRoCNhYzj_oEAmuj2hDj6mWs
Project ID: pkiwwdrzsbfqhbmnmfnl

# Workflow Automation
n8n URL: https://vmi2976539.contaboserver.net
n8n API Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmNjJjZDQxZS1lZjAyLTQyN2QtYmUwZi02NjNlYjc3NDVhN2EiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzY1OTI5NDQxfQ.oeIcFjJzoglxjCWVl53ot4_cvc-DSmXj9JIi1AqFSIU
```

---

## FIRST TIME SETUP

**Step 1: Create Tables in Supabase**
1. Go to https://supabase.com/dashboard/project/pkiwwdrzsbfqhbmnmfnl/sql
2. Copy contents of `supabase_schema.sql`
3. Paste and run in SQL Editor
4. This creates all 11 tables and seeds initial keywords

**Step 2: Verify Setup**
```bash
python scripts/init_database.py
```

**Step 3: Test Scraper**
```bash
python scripts/etsy_scraper.py daily
```

---

## COMMANDS

```yaml
"scrape [query]":
  Execute search scrape, store results
  Example: "scrape cosmic witch sticker"

"scrape all":
  Run full keyword batch (2000+ queries)
  Takes several hours

"scrape shop [url]":
  Deep scrape a competitor shop
  Example: "scrape shop https://etsy.com/shop/MysticMoonDesigns"

"analyze":
  Run pattern detection on collected data
  Returns title patterns, price sweet spots, tag effectiveness

"analyze [niche]":
  Run analysis for specific niche
  Example: "analyze cosmic witch"

"what's selling":
  Show top bestsellers with revenue estimates

"what to make":
  Direct recommendations on products to create

"find opportunities":
  Run gap analysis, score opportunities

"find competitors":
  List top shops in niche

"patterns titles":
  Show title word/phrase patterns from bestsellers

"patterns tags":
  Show most effective tags

"patterns prices":
  Show price sweet spots by product type

"report":
  Generate full intelligence report (JSON)

"status":
  Database stats, last scrape times, data freshness
```

---

## DATA COLLECTED

**Per Listing:**
- ID, URL, Title, Description
- Price, Original Price, Free Shipping
- Reviews Count, Rating, Sales Count, Favorites
- Bestseller Badge, Star Seller Badge
- Shop Name, Shop URL
- All Images
- All Tags
- Category, Product Type
- Search Query, Position
- First Seen, Last Seen

**Per Shop:**
- Name, URL, Location
- Total Sales, Reviews, Rating
- Listing Count, Admirers
- Member Since, Star Seller
- About Text

**Per Search:**
- Query, Total Results
- Price Range, Avg Reviews
- Bestseller Count
- All Listings in Results

---

## PATTERNS DETECTED

**Title Patterns:**
- Which words appear most in bestsellers
- Which phrases correlate with high reviews
- Optimal title length
- Keyword positioning

**Tag Patterns:**
- Most used tags in bestsellers
- Tag + sales correlation
- Tag combinations that work together
- Underused effective tags

**Price Patterns:**
- Price range by product type
- Sweet spots (25th-75th percentile)
- Bestseller average prices
- Free shipping impact

---

## OPPORTUNITIES SCORED

```yaml
OPPORTUNITY_SCORE (0-10):
  Demand (0-3):
    - Based on search volume, existing sales

  Competition (0-3):
    - Lower = better score
    - Quality of competition matters

  Margin (0-2):
    - Higher prices = better

  Execution (0-2):
    - Can we make this easily?

Priority:
  8-10: HIGH - Make immediately
  6-7.9: MEDIUM - Queue for next batch
  <6: LOW - Consider later
```

---

## KEYWORD MATRIX

**Niches:** witch, witchy, witchcraft, pagan, wiccan, occult, cosmic witch, moon witch, cottage witch, kitchen witch, green witch, sea witch, hedge witch, gothic witch

**Products:** sticker, poster, print, wall art, tapestry, mug, journal, notebook, blanket, shirt, tote bag, digital download, printable, grimoire pages

**Modifiers:** aesthetic, gift, decor, vintage, minimalist, boho, celestial, botanical

**Total Combinations:** 2000+ unique search queries

---

## DATABASE TABLES (Supabase)

```sql
etsy_listings        - Core product data
etsy_shops           - Competitor profiles
etsy_searches        - Search result tracking
etsy_search_listings - Junction table
etsy_keywords        - Keyword performance
etsy_price_history   - Price changes over time
etsy_reviews         - Customer review analysis
etsy_trends          - Trend detection
etsy_patterns        - Detected patterns
etsy_opportunities   - Scored opportunities
etsy_scrape_jobs     - Job queue and status
```

---

## SCRIPTS

```
scripts/init_database.py    - Database setup & keyword seeding
scripts/etsy_scraper.py     - Browser automation & data collection
scripts/pattern_analyzer.py - Pattern detection & opportunity finding
supabase_schema.sql         - SQL to create all tables
```

---

## RATE LIMITS

- Max 100 requests per hour
- Random delays 2-6 seconds
- Residential proxy rotation
- Human-like behavior patterns

If blocked: Wait 30 min, retry with different proxy

---

## OUTPUT EXAMPLES

**"what to make" output:**
```
WHAT TO MAKE NEXT:

1. COPY THESE BESTSELLERS:
   - Cosmic Moon Phase Wall Art Celestial Poster
     $4,500 est. revenue
     2,345 reviews
     Tags: witch, celestial, moon art, wall decor

2. FILL THESE GAPS:
   - "sea witch tapestry" has 5000 searches but only 3 quality listings
     Score: 8.5/10 | HIGH PRIORITY
```

**"patterns tags" output:**
```
TOP PERFORMING TAGS:
  - 'witch' - 234x (avg 156 reviews)
  - 'witchy gift' - 89x (avg 203 reviews)
  - 'moon phase' - 67x (avg 189 reviews)
  - 'celestial' - 54x (avg 167 reviews)
```

---

## NICHE: Witchcraft POD

**Sub-niches tracked:**
- Cosmic witch (celestial, moon, stars)
- Cottage witch (cozy, kitchen, herbs)
- Green witch (botanical, nature, plants)
- Sea witch (ocean, shells, mermaid)
- Gothic witch (dark, Victorian)

**Products tracked:**
- Stickers, Posters, Tapestries
- Mugs, Journals, Blankets
- Digital downloads, Printables

---

**This agent finds what works. You just make it.**
