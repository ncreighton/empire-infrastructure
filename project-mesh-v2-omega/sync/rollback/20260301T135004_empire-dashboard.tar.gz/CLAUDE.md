<!-- MESH:START -->

# -----------------------------------------------------------
# PROJECT MESH v2.0   AUTO-GENERATED CONTEXT
# Project: Empire Dashboard
# Category: infrastructure
# Priority: critical
# Compiled: 2026-03-01 13:49
# -----------------------------------------------------------

# EMPIRE GLOBAL RULES
> These rules apply to EVERY project. No exceptions.

## Core Principles
1. **Never hardcode API keys, webhook URLs, or secrets** — Use environment variables
2. **Always use shared-core systems when available** — Check the registry first
3. **All API calls must use retry logic** — Use the api-retry shared system
4. **Images must be optimized before upload** — Use image-optimization system
5. **Content must pass SEO validation** — Use seo-toolkit system
6. **Never reference deprecated methods** — Check BLACKLIST.md below

## Technical Standards
- All WordPress sites use Blocksy or Astra themes on Hostinger
- All automation runs through n8n (ZimmWriter is DEPRECATED)
- All content generation uses Claude API (never GPT)
- All sites use LiteSpeed cache
- All affiliate links use affiliate-link-manager system

## Quality Standards
- Content demonstrates E-E-A-T signals
- Target featured snippets where applicable
- Proper schema markup on every page
- Images have alt text with target keywords
- Internal linking follows topical cluster strategy

## Brand Voice
- Each site has its own voice (see category context below)
- Never use generic AI-sounding language
- Never reference being AI-generated
- Content must feel human-written and authentic

## n8n Automation
- All content pipelines run through n8n workflows
- Use Steel.dev for browser automation with 10min keep-alive pings
- BrowserUse as fallback when Steel.dev fails
- All webhooks use environment variables, never hardcoded URLs

# DEPRECATED METHODS — NEVER USE THESE

> This file is auto-included in every project's CLAUDE.md.
> Updated: 2026-02-28

## Content Generation
### ❌ NEVER use ZimmWriter or ZimmWriter API
- **Replacement**: n8n content pipeline + Claude API
- **Reason**: Deprecated in favor of Claude-native workflows
- **Stage**: REMOVED

### ❌ NEVER use GPT/OpenAI for content generation
- **Replacement**: Claude API (Anthropic)
- **Reason**: All content uses Claude for consistency and quality

## API Patterns
### ❌ NEVER hardcode webhook URLs
- **Replacement**: Use environment variables or config.get('webhooks.name')
- **Reason**: Security risk and maintenance nightmare

### ❌ NEVER make API calls without retry logic
- **Replacement**: Use shared-core/api-retry system
- **Reason**: APIs fail. Always retry with exponential backoff.

### ❌ NEVER use fetch() directly for external APIs
- **Replacement**: Use the api-retry wrapper which handles retries, timeouts, and error logging
- **Reason**: Raw fetch has no retry, no timeout, no error handling

## WordPress
### ❌ NEVER use Yoast SEO plugin
- **Replacement**: RankMath
- **Reason**: Standardized across all sites on RankMath

### ❌ NEVER edit theme files directly
- **Replacement**: Use child theme or Blocksy customizer
- **Reason**: Updates will overwrite direct edits

## Substack
### ❌ NEVER use witchcraftforbeginners.substack.com
- **Replacement**: witchcraftb.substack.com
- **Reason**: Correct URL is witchcraftb.substack.com

## Browser Automation
### ❌ NEVER use Puppeteer directly
- **Replacement**: Steel.dev with BrowserUse fallback
- **Reason**: Standardized on Steel.dev for session management
- **Note**: Steel.dev sessions expire after 15min idle — implement keep-alive pings

## Infrastructure Context
- **Services**: Dashboard (8000), Vision (8002), Grimoire (8080), VideoForge (8090), BMC (8095)
- **Startup**: VBS launchers -> PowerShell -> service binary via Task Scheduler
- **Monitoring**: Empire dashboard checks all service health every 30s
- **Deployment**: VPS at 217.216.84.245, Docker compose for remote services

## Revenue-Critical Project
⚠️ This project directly generates significant revenue. Extra care required:
- Test ALL changes on staging before production
- Never modify affiliate links without verification
- Content changes need SEO impact assessment
- Downtime directly impacts revenue — minimize deploy risks
- Monitor analytics after any major change for 48 hours
- Backup before any theme/plugin updates


## Shared Systems (Current Versions)

| System | Version | Criticality | Usage |
|--------|---------|-------------|-------|
| api-retry | 1.0.0 [OK] | high | hourly |


## Relevant Knowledge Base Entries

- API Endpoints
- AVOID: [X] NEVER use GPT/OpenAI for content generation
- AVOID: [X] NEVER use Puppeteer directly
- AVOID: [X] NEVER use ZimmWriter or ZimmWriter API
- Browser Automation
- API Cost Optimization Rules
- Tech Stack
- AVOID: [X] NEVER use Yoast SEO plugin
- API Patterns

## Self-Check Before Starting Work
Before writing any code or content for Empire Dashboard:
1. [OK] Am I using the latest shared systems? (Check version table above)
2. [OK] Am I avoiding ALL deprecated methods? (Check blacklist above)  
3. [OK] Am I using the correct brand voice for infrastructure vertical?
4. [OK] Am I using api-retry for all external API calls?
5. [OK] Am I using environment variables for secrets/webhooks?

<!-- MESH:END -->

# Empire Dashboard

Real-time monitoring dashboard for the 14-site WordPress publishing empire.

## Related Project

**Design Consistency System** (`../design-consistency-system/`) provides deep auditing, design enforcement, and content optimization. See `../EMPIRE-PROJECTS.md` for how these projects work together.

| This Project | Design Consistency System |
|--------------|---------------------------|
| Real-time monitoring | Deep auditing |
| Quick status checks | Comprehensive analysis |
| htmx live updates | Visual regression testing |
| Lightweight & fast | AI content optimization |

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Start the dashboard
start.bat
# Or manually:
python -m uvicorn main:app --reload --port 8000
```

**Access:** http://localhost:8000

## Features

### Site Health Matrix
- Real-time status for all 16 WordPress sites
- Post/page counts, response times
- Quick links to site and wp-admin
- Color-coded status (online/degraded/offline)

### Content Pipeline
- Zimm pipeline stage tracking (Research → Published)
- Articles in progress count
- Stage-by-stage progress bars
- Supabase integration

### n8n Workflow Monitoring
- 13 workflow status cards
- Active/inactive state
- Recent execution history
- Success/error/running counts

### Alerts Center
- Critical/warning/info severity levels
- Real-time updates (30s refresh)
- Dismissable alerts

## Architecture

```
empire-dashboard/
├── main.py              # FastAPI application
├── config.py            # Configuration & credentials
├── start.bat            # Windows launcher
│
├── api/                 # REST endpoints
│   ├── sites.py         # WordPress site status
│   ├── workflows.py     # n8n workflows
│   ├── pipeline.py      # Content pipeline
│   ├── analytics.py     # Traffic & SEO
│   └── alerts.py        # Alert management
│
├── services/            # API clients
│   ├── wordpress.py     # WP REST API client
│   ├── n8n.py           # n8n API client
│   ├── supabase.py      # Supabase client
│   └── cache.py         # In-memory TTL cache
│
├── templates/           # Jinja2 HTML templates
│   ├── base.html        # Base layout
│   ├── dashboard.html   # Main dashboard
│   └── partials/        # Component templates
│
└── static/              # CSS & JS assets
    ├── css/dashboard.css
    └── js/charts.js
```

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/sites` | All sites with status |
| `GET /api/sites/summary` | Aggregated metrics |
| `GET /api/sites/{id}` | Single site details |
| `GET /api/workflows` | n8n workflow status |
| `GET /api/workflows/executions` | Recent executions |
| `POST /api/workflows/{id}/toggle` | Activate/deactivate |
| `GET /api/pipeline/stats` | Pipeline stage counts |
| `GET /api/pipeline/items` | Content items |
| `GET /api/analytics/summary` | Traffic summary |
| `GET /api/alerts` | Active alerts |

## Data Refresh Intervals

| Data | Interval | Method |
|------|----------|--------|
| Sites | 60s | htmx polling |
| Workflows | 30s | htmx polling |
| Pipeline | 60s | htmx polling |
| Analytics | 5 min | Cached |
| Alerts | 30s | htmx polling |

## Configuration

Credentials are loaded from:
- `../config/sites.json` - WordPress sites
- Hardcoded in `config.py` - n8n & Supabase API keys

### n8n Instance
- **URL:** https://vmi2976539.contaboserver.net
- **API Key:** Configured in config.py

### Supabase Instance
- **URL:** https://pkiwwdrzsbfqhbmnmfnl.supabase.co
- **Project:** pkiwwdrzsbfqhbmnmfnl

## Tech Stack

- **Backend:** Python 3.11 + FastAPI
- **Frontend:** Jinja2 + Tailwind CSS + htmx
- **Charts:** Chart.js
- **HTTP Client:** httpx (async)

## Dependencies

```
fastapi==0.109.0
uvicorn[standard]==0.27.0
jinja2==3.1.2
python-multipart==0.0.6
httpx==0.26.0
python-dotenv==1.0.0
```

## Extending

### Add new data source
1. Create service client in `services/`
2. Add API endpoint in `api/`
3. Include router in `main.py`
4. Add UI section in `templates/dashboard.html`

### Add new site
Update `../config/sites.json` - dashboard auto-discovers.

## Troubleshooting

### Sites showing offline
- Check WordPress credentials in sites.json
- Verify site is accessible
- Check app password hasn't expired

### n8n workflows not loading
- Verify n8n instance is running
- Check API key in config.py
- Check VPS connectivity

### Dashboard won't start
```bash
# Check Python version
python --version  # Need 3.8+

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

---

## API Cost Optimization Rules

### Model Selection (MANDATORY)
When generating code that calls Anthropic's API:

1. **Default to Sonnet** (`claude-sonnet-4-20250514`) for most tasks
2. **Use Haiku** (`claude-haiku-4-5-20251001`) for:
   - Classification tasks
   - Intent detection
   - Simple data extraction
   - Yes/no decisions
   - Formatting/conversion
   - Tag generation
3. **Reserve Opus** (`claude-opus-4-20250514`) ONLY for:
   - Complex multi-step reasoning
   - Critical business decisions
   - Nuanced editorial judgment

### Prompt Caching (ALWAYS ENABLE)
When system prompts exceed 2,048 tokens, ALWAYS use cache_control:

```python
message = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=2048,
    system=[
        {
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[{"role": "user", "content": user_input}]
)
```

### Token Limits
| Output Type | max_tokens |
|-------------|------------|
| Yes/no, classification | 50-100 |
| Short response | 200-500 |
| Article section | 1000-2000 |
| Full article | 3000-4096 |

### Quick Reference
```
Model Strings (Dec 2025):
- claude-haiku-4-5-20251001    → Simple tasks
- claude-sonnet-4-20250514     → Default
- claude-opus-4-20250514       → Complex only

Pricing per 1M tokens:
- Haiku:  $0.80 in / $4.00 out
- Sonnet: $3.00 in / $15.00 out
- Opus:   $15.00 in / $75.00 out
- Cache reads: 90% discount
- Batch API: 50% discount
```
